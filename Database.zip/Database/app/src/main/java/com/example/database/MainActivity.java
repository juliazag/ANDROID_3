package com.example.database;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    DatabaseReference databaseReference;
    List<Books> booksList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseReference = FirebaseDatabase.getInstance().getReference("Books");
        listView = findViewById(R.id.listView);

        booksList = new ArrayList<>();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), AddActivity.class);
                startActivityForResult(intent, RESULT_OK);
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Books book = booksList.get(position);
                showDetails(book.getId(),book.getTytul(),book.getAutor(),book.getJezyk(),book.getData(),book.getLiczba());
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Books book = booksList.get(position);
                showDialog(book.getId(),book.getTytul(),book.getAutor(),book.getJezyk(),book.getData(),book.getLiczba());
                return false;
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                booksList.clear();

                for(DataSnapshot bookSnapshot : snapshot.getChildren()){
                    Books book = bookSnapshot.getValue(Books.class);
                    booksList.add(book);
                }

                BookList adapter = new BookList(MainActivity.this, booksList);
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void showDialog(final String bookId, final String bookTitle, final String bookAuthor, final String bookLang, final String bookRelease, final String bookNr){
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this, R.style.MyDialogTheme);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.dialog,null);
        dialogBuilder.setView(dialogView);

        final EditText editTitle = dialogView.findViewById(R.id.title_e);
        final EditText editAuthor = dialogView.findViewById(R.id.author_e);
        final EditText editLang = dialogView.findViewById(R.id.language_e);
        final EditText editRelease = dialogView.findViewById(R.id.release_e);
        final EditText editNr = dialogView.findViewById(R.id.number_e);
        final Button buttonEdit = dialogView.findViewById(R.id.edit);
        final Button buttonDelete = dialogView.findViewById(R.id.delete);


        dialogBuilder.setTitle("Updating book: " + bookTitle);
        dialogBuilder.setCancelable(true);
        final AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();

        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = editTitle.getText().toString().trim();
                String author = editAuthor.getText().toString().trim();
                String lang = editLang.getText().toString().trim();
                String release = editRelease.getText().toString().trim();
                String nr = editNr.getText().toString().trim();

                if (title.isEmpty() && author.isEmpty() && lang.isEmpty() && release.isEmpty() && nr.isEmpty()){
                    alertDialog.dismiss();
                }
                if(title.isEmpty()){
                    title = bookTitle;
                }
                if(author.isEmpty()){
                    author = bookAuthor;
                }
                if(lang.isEmpty()){
                    lang = bookLang;
                }
                if(release.isEmpty()){
                    release = bookRelease;
                }
                if(nr.isEmpty()){
                    nr = bookNr;
                }

                updateBook(bookId, title, author, lang, release, nr);
                alertDialog.dismiss();
            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteBook(bookId);
                alertDialog.dismiss();
            }
        });
    }

    private boolean updateBook(String id, String title, String author, String lang, String release, String nr){
        DatabaseReference dRefUpdate = FirebaseDatabase.getInstance().getReference("Books").child(id);
        Books book = new Books(id, title, author, lang, release, nr);
        dRefUpdate.setValue(book);

        Toast.makeText(this, "Book updated!", Toast.LENGTH_LONG).show();
        return true;
    }

    private void deleteBook(String id){
        DatabaseReference dRefDelete = FirebaseDatabase.getInstance().getReference("Books").child(id);
        dRefDelete.removeValue();
        Toast.makeText(this, "Book deleted!", Toast.LENGTH_LONG).show();
    }

    @SuppressLint("SetTextI18n")
    private void showDetails(final String bookId, final String bookTitle, final String bookAuthor, final String bookLang, final String bookRelease, final String bookNr){
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this, R.style.MyDialogTheme);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.details, null);
        dialogBuilder.setView(dialogView);

        final TextView Title = dialogView.findViewById(R.id.title_l);
        final TextView Author = dialogView.findViewById(R.id.author_l);
        final TextView Lang = dialogView.findViewById(R.id.language_l);
        final TextView Release = dialogView.findViewById(R.id.release_l);
        final TextView Nr = dialogView.findViewById(R.id.number_l);

        Title.setText(bookTitle);
        Author.setText(bookAuthor);
        Lang.setText(bookLang);
        Release.setText(bookRelease);
        Nr.setText(bookNr);

        dialogBuilder.setTitle("Details of book: " + bookTitle);
        dialogBuilder.setCancelable(true);
        final AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
    }
}
