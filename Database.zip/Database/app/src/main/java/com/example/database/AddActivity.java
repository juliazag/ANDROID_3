package com.example.database;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

public class AddActivity extends AppCompatActivity {

    DatabaseReference databaseReference;

    /*
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    Map<String, Object> books = new HashMap<String, Object>();

    public static final String TITLE_KEY = "Title";
    public static final String AUTHOR_KEY = "Author";
    public static final String LANG_KEY = "Language";
    public static final String RELEASE_KEY = "Release";
    public static final String NUMBER_KEY = "Number";

     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
    }

    public void addClick(View view) {
        EditText taskTitle = findViewById(R.id.title);
        EditText taskAuthor = findViewById(R.id.author);
        EditText taskLanguage = findViewById(R.id.language);
        EditText taskRelease = findViewById(R.id.release);
        EditText taskNumber = findViewById(R.id.number);

        String taskT = taskTitle.getText().toString().trim();
        String taskA = taskAuthor.getText().toString().trim();
        String taskL = taskLanguage.getText().toString().trim();
        String taskR = taskRelease.getText().toString().trim();
        String taskN = taskNumber.getText().toString().trim();

        Context context = getApplicationContext();

        if (taskT.isEmpty() || taskA.isEmpty() || taskL.isEmpty() || taskR.isEmpty() || taskN.isEmpty()){
            Toast.makeText(context, "Fill all inputs!", Toast.LENGTH_SHORT).show();
        }
        else if(taskR.length()<4){
            Toast.makeText(context, "Wrong release year!", Toast.LENGTH_SHORT).show();
        }
        else if(!letter(taskL)){
            Toast.makeText(context, "Wrong original language! Use only letters!", Toast.LENGTH_SHORT).show();
        }
        else if(!number(taskN)) {
            Toast.makeText(context, "Wrong number of pages! Use only numbers!", Toast.LENGTH_SHORT).show();
        }
        else{
            databaseReference = FirebaseDatabase.getInstance().getReference("Books");
            String id = databaseReference.push().getKey();
            Books books = new Books(id,taskT,taskA,taskL,taskR,taskN);
            databaseReference.child(id).setValue(books);

            Toast.makeText(context, "Added " + taskT + " to list!", Toast.LENGTH_SHORT).show();
            setResult(RESULT_OK);
            finish();
        }
    }

    public boolean letter(String word){
        for(int i = 0; i < word.length(); i++){
            if(Character.isDigit(word.charAt(i))) return false;
        }
        return true;
    }

    public boolean number(String word){
        for(int i = 0; i < word.length(); i++){
            if(!Character.isDigit(word.charAt(i))) return false;
        }
        return true;
    }
}


