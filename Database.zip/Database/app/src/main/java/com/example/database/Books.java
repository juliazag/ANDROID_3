package com.example.database;

public class Books {
    private String id;
    private String tytul;
    private String autor;
    private String jezyk;
    private String data;
    private String liczba;

    public Books(){

    }

    public Books(String id, String tytul, String autor, String jezyk, String data, String liczba){
        this.id = id;
        this.tytul = tytul;
        this.autor = autor;
        this.jezyk = jezyk;
        this.data = data;
        this.liczba = liczba;
    }

    public String getId(){
        return id;
    }

    public String getTytul(){
        return tytul;
    }

    public String getAutor(){
        return autor;
    }

    public String getJezyk(){
        return jezyk;
    }

    public String getData(){
        return data;
    }

    public String getLiczba(){
        return liczba;
    }

    public String toString(){
        return this.tytul + " - " + autor;
    }
}
