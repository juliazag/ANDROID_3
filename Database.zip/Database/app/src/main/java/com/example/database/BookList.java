package com.example.database;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class BookList extends ArrayAdapter<Books> {
    private Activity context;
    private List<Books> booksList;

    public BookList(Activity context, List<Books> booksList){
        super(context, R.layout.list_layout, booksList);
        this.context = context;
        this.booksList = booksList;
    }

    @SuppressLint("SetTextI18n")
    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.list_layout, null, true);

        TextView textViewTitle = listViewItem.findViewById(R.id.title_l);

        Books book = booksList.get(position);

        textViewTitle.setText("Title: " + book.getTytul() + "\n" + "Author: " + book.getAutor());

        return listViewItem;
    }
}
